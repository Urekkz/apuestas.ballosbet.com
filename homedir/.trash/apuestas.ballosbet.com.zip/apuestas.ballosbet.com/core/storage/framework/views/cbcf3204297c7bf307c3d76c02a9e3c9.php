

<?php $__env->startSection('bet'); ?>
<?php
    $betPlacedIds = collect(session()->get('bets'))
        ->pluck('outcome_id')
        ->toArray();

    $path = storage_path('app/stream_url.txt');
    $streamUrl = file_exists($path) ? trim(file_get_contents($path)) : '';
?>


<div class="col-12 mb-3">
    <?php echo $__env->make($activeTemplate . 'partials.slider', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>


<div class="live-banner">
    PELEA DE GALLOS EN VIVO <span class="live-dot">●</span>
</div>


<div class="col-12 mb-4">
    <h3 class="text-center" style="color:#fff;margin-bottom:15px;font-weight:700;letter-spacing:.2px;"
        <?php if($streamUrl): ?>
            <span style="display:inline-block;width:10px;height:10px;margin-left:.5rem;background:#ff3b30;border-radius:50%;vertical-align:middle;"></span>
        <?php endif; ?>
    </h3>

    <div class="stream-frame">
        <?php if($streamUrl): ?>
            <iframe
                src="https://www.facebook.com/plugins/video.php?href=<?php echo e(urlencode($streamUrl)); ?>&show_text=false&autoplay=true"
                width="100%" height="480"
                style="border:none;overflow:hidden;border-radius:10px;"
                scrolling="no" frameborder="0"
                allowfullscreen="true"
                allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share">
            </iframe>
        <?php else: ?>
            <p class="no-stream-message">Esperando transmisión en vivo...</p>
        <?php endif; ?>
    </div>
</div>


<?php if(auth()->guard()->check()): ?>
    <?php if(auth()->user()->status == 1): ?>
        
        <?php if(!$streamUrl): ?>
            <div class="no-stream-message">
                <svg width="38" height="38" viewBox="0 0 24 24" fill="none" aria-hidden="true"
                    style="display:block;margin:0 auto;color:#ff6600;">
                    <path d="M3 5h18v14H3z" stroke="currentColor" stroke-width="1.5"></path>
                    <path d="M10 9l5 3-5 3V9z" fill="currentColor"></path>
                </svg>
                <p style="margin:8px 0 0;font-weight:700;letter-spacing:.2px;">No hay en vivos por ahora</p>
            </div>
        <?php endif; ?>
    <?php else: ?>
        
        <div class="inactive-message">
            <p>Tu cuenta está inactiva. Contacta con soporte.</p>
            <form method="POST" action="<?php echo e(route('user.logout')); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-danger mt-2">Cerrar sesión</button>
            </form>
        </div>
    <?php endif; ?>
<?php else: ?>
    
    <div id="stream-login-placeholder" class="no-stream-message">
        <p>Inicia sesión para ver el stream en vivo</p>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            setTimeout(() => {
                const modal = document.querySelector('#loginModal');
                if (modal) {
                    const modalInstance = new bootstrap.Modal(modal);
                    modalInstance.show();
                } else {
                    console.warn('⚠️ No se encontró el #loginModal en la página.');
                }
            }, 1000);
        });
    </script>
<?php endif; ?>


<div class="col-12 top-sticky mb-3">
    <?php echo $__env->make($activeTemplate . 'partials.leagues', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>


<div class="col-12">
    <div class="betting-body">
        <div class="row g-3">
            <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $outrightMarket = $game->markets->where('market_type', 'outrights')->first();
                ?>

                <?php if($outrightMarket): ?>
                    <div class="col-12">
                        <div class="sports-card">
                            <div class="sports-card-wrapper sports-card-wrapper-lg">
                                <?php if (isset($component)) { $__componentOriginal98383b2ae63aa9d94fb4a1c904602ff3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal98383b2ae63aa9d94fb4a1c904602ff3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.odds-teams','data' => ['game' => $game,'marketTitle' => $outrightMarket->title]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.odds-teams'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['game' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($game),'marketTitle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($outrightMarket->title)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal98383b2ae63aa9d94fb4a1c904602ff3)): ?>
<?php $attributes = $__attributesOriginal98383b2ae63aa9d94fb4a1c904602ff3; ?>
<?php unset($__attributesOriginal98383b2ae63aa9d94fb4a1c904602ff3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal98383b2ae63aa9d94fb4a1c904602ff3)): ?>
<?php $component = $__componentOriginal98383b2ae63aa9d94fb4a1c904602ff3; ?>
<?php unset($__componentOriginal98383b2ae63aa9d94fb4a1c904602ff3); ?>
<?php endif; ?>
                                <?php $__currentLoopData = $outrightMarket->outcomes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $outcome): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="sports-card-inner">
                                        <div class="sports-card-top-inner sports-card-heading">
                                            <span class="team-select-title"><?php echo e($outcome->name); ?></span>
                                        </div>
                                        <div class="sports-card-body">
                                            <div class="option-odd-lists text-center d-flex flex-column align-items-center">
                                                <?php if (isset($component)) { $__componentOriginald71f8655bdaaebdbc1fa6cb0f7f551bd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald71f8655bdaaebdbc1fa6cb0f7f551bd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.odds-button','data' => ['outcome' => $outcome]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.odds-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['outcome' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($outcome)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald71f8655bdaaebdbc1fa6cb0f7f551bd)): ?>
<?php $attributes = $__attributesOriginald71f8655bdaaebdbc1fa6cb0f7f551bd; ?>
<?php unset($__attributesOriginald71f8655bdaaebdbc1fa6cb0f7f551bd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald71f8655bdaaebdbc1fa6cb0f7f551bd)): ?>
<?php $component = $__componentOriginald71f8655bdaaebdbc1fa6cb0f7f551bd; ?>
<?php unset($__componentOriginald71f8655bdaaebdbc1fa6cb0f7f551bd); ?>
<?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="col-12">
                        <div class="sports-card">
                            <div class="sports-card-wrapper">
                                <?php if (isset($component)) { $__componentOriginal98383b2ae63aa9d94fb4a1c904602ff3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal98383b2ae63aa9d94fb4a1c904602ff3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.odds-teams','data' => ['game' => $game]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.odds-teams'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['game' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($game)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal98383b2ae63aa9d94fb4a1c904602ff3)): ?>
<?php $attributes = $__attributesOriginal98383b2ae63aa9d94fb4a1c904602ff3; ?>
<?php unset($__attributesOriginal98383b2ae63aa9d94fb4a1c904602ff3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal98383b2ae63aa9d94fb4a1c904602ff3)): ?>
<?php $component = $__componentOriginal98383b2ae63aa9d94fb4a1c904602ff3; ?>
<?php unset($__componentOriginal98383b2ae63aa9d94fb4a1c904602ff3); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal39581b76badd8970b0c0e8dfc23a5498 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal39581b76badd8970b0c0e8dfc23a5498 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.odds-list','data' => ['game' => $game,'marketType' => 'h2h','betPlacedIds' => $betPlacedIds]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.odds-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['game' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($game),'marketType' => 'h2h','betPlacedIds' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($betPlacedIds)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal39581b76badd8970b0c0e8dfc23a5498)): ?>
<?php $attributes = $__attributesOriginal39581b76badd8970b0c0e8dfc23a5498; ?>
<?php unset($__attributesOriginal39581b76badd8970b0c0e8dfc23a5498); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal39581b76badd8970b0c0e8dfc23a5498)): ?>
<?php $component = $__componentOriginal39581b76badd8970b0c0e8dfc23a5498; ?>
<?php unset($__componentOriginal39581b76badd8970b0c0e8dfc23a5498); ?>
<?php endif; ?>
                            </div>
                        </div>

                        
                        <div class="col-12 mt-3">
                            <?php if (isset($component)) { $__componentOriginald30468e774771c01bbdd58a628532d02 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald30468e774771c01bbdd58a628532d02 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.open-bets','data' => ['game' => $game]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.open-bets'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['game' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($game)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald30468e774771c01bbdd58a628532d02)): ?>
<?php $attributes = $__attributesOriginald30468e774771c01bbdd58a628532d02; ?>
<?php unset($__attributesOriginald30468e774771c01bbdd58a628532d02); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald30468e774771c01bbdd58a628532d02)): ?>
<?php $component = $__componentOriginald30468e774771c01bbdd58a628532d02; ?>
<?php unset($__componentOriginald30468e774771c01bbdd58a628532d02); ?>
<?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <?php if(blank($games)): ?>
            <div class="empty-message mt-3 text-center">
                <img class="img-fluid" src="<?php echo e(asset($activeTemplateTrue . 'images/empty_message.png')); ?>" alt="<?php echo app('translator')->get('image'); ?>">
                <p><?php echo app('translator')->get('No game available'); ?></p>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('style'); ?>
<style>
    /* pading */
    .live-banner {
        background: linear-gradient(90deg, #ff6600, #ff914d);
         color: hsl(var(--white));
        font-weight: 700;
        text-align: center;
        padding: 10px 0;
        border-radius: 10px;
        font-size: 1.2rem;
        letter-spacing: 0.5px;
        box-shadow: 0 4px 10px rgba(255,102,0,0.3);
        margin-bottom: 1rem;
        position: relative;
    }

    /* live */
    .live-dot {
        color: #ff0000;
        font-size: 1.2rem;
        margin-left: 8px;
        animation: blink 1s infinite;
    }
    @keyframes blink {
        0%, 100% { opacity: 1; }
        50% { opacity: 0; }
    }

    /*Marco de video */
    .stream-frame {
        background: #1b1b1b;
        border: 2px solid rgba(255, 102, 0, 0.4);
        border-radius: 12px;
        padding: 10px;
        max-width: 950px;
        margin: 0 auto 2rem;
        box-shadow: 0 0 25px rgba(255, 102, 0, 0.2);
        transition: 0.3s ease-in-out;
    }
    .stream-frame:hover {
        box-shadow: 0 0 35px rgba(255, 102, 0, 0.4);
    }

    /* ️s */
    .sports-card {
        background: #232834;
        border-radius: 12px;
        padding: 1rem;
        color: #fff;
        box-shadow: 0 3px 10px rgba(0,0,0,0.3);
        transition: transform 0.25s ease, box-shadow 0.25s ease;
    }
    .sports-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 5px 14px rgba(255,102,0,0.3);
    }

    .sports-card-heading {
        color: #ff914d;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: .3px;
    }

    /* msj */
    .empty-message, .no-stream-message, .inactive-message {
        text-align: center;
        color: #ccc;
        font-weight: 600;
        padding: 1.5rem;
        border-radius: 10px;
        background: rgba(255,255,255,0.05);
        box-shadow: inset 0 0 15px rgba(255,102,0,0.1);
    }

    /* responsive */
    @media (max-width: 768px) {
        .stream-frame iframe {
            height: 320px;
        }
        .live-banner {
            font-size: 1rem;
            padding: 8px;
        }
    }
</style>
<?php $__env->stopPush(); ?>


<?php $__env->startPush('script'); ?>
<script src="<?php echo e(asset($activeTemplateTrue . 'js/betting.js')); ?>"></script>
<script>
    (function($) {
        "use strict";
        const slider = $('.sports-card');
        let isDown = false, startX, scrollLeft;

        slider.on('mousedown', function(e) {
            isDown = true;
            startX = e.pageX - slider.offset().left;
            scrollLeft = slider.scrollLeft();
            slider.css('cursor', 'grabbing');
        });
        slider.on('mouseleave mouseup', function() {
            isDown = false;
            slider.css('cursor', 'grab');
        });
        slider.on('mousemove', function(e) {
            if(!isDown) return;
            e.preventDefault();
            const x = e.pageX - slider.offset().left;
            slider.scrollLeft(scrollLeft - (x - startX) * 2);
        });
    })(jQuery);
</script>
<?php $__env->stopPush(); ?>



<?php echo $__env->make($activeTemplate . 'layouts.bet', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home3/dannygue/apuestas.ballosbet.com/core/resources/views/templates/basic/home.blade.php ENDPATH**/ ?>