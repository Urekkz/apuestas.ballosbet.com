<?php
    $footerElements = getContent('footer.element', false, null, true);
?>

<div class="row align-items-center justify-content-between">
    <div class="col-sm-6">
        <p class="xsm-text text-sm-start m-0 text-center">
            <?php echo app('translator')->get('Copyright'); ?> &copy; <?php echo date('Y') ?> <a class="t-link--base" href="<?php echo e(route('home')); ?>"><?php echo e(__(gs('site_name'))); ?></a> <?php echo app('translator')->get('Todos los derechos reservados'); ?>
        </p>
    </div>
    <div class="col-sm-6">
        <ul class=" gap-1 list list--row justify-content-center justify-content-sm-end mt-sm-0 align-items-center mt-2 flex-wrap">
            <?php $__currentLoopData = $footerElements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $footer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <span class="d-inline-block footer__flag">
                        <img class="footer__flag-img" src="<?php echo e(frontendImage('footer', @$footer->data_values->payment_method_image, '130x50')); ?>" alt="<?php echo app('translator')->get('image'); ?>">
                    </span>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div>
<?php /**PATH /home3/dannygue/apuestas.ballosbet.com/core/resources/views/templates/basic/partials/footer_bottom.blade.php ENDPATH**/ ?>