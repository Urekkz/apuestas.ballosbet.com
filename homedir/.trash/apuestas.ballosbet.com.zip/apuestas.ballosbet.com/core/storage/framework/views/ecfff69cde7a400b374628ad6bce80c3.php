<div class="container-fluid mt-auto px-0">
    <div class="footer footer--dark">
        <div class="container">
            <?php echo $__env->make($activeTemplate . 'partials.footer_top', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>

    <div class="footer-bottom footer-bottom--dark">
        <div class="container">
            <?php echo $__env->make($activeTemplate . 'partials.footer_bottom', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>
</div>
<?php /**PATH /home3/dannygue/apuestas.ballosbet.com/core/resources/views/templates/basic/partials/footer.blade.php ENDPATH**/ ?>