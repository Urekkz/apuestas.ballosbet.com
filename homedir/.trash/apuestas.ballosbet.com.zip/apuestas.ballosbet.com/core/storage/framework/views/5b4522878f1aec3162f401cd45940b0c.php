<header class="header-primary user-header-primary">
    <div class="container">
        <div class="row g-0 align-items-center">
            <div class="header-fluid-custom-parent">
                <a class="logo" href="<?php echo e(route('home')); ?>"><img class="img-fluid logo__is" src="<?php echo e(siteLogo()); ?>" alt="<?php echo app('translator')->get('logo'); ?>"></a>
                <nav class="primary-menu-container justify-content-end">

                    <ul class="list list--row primary-menu justify-content-end align-items-center right-side-nav gap-3 gap-sm-4">

                        <?php if(gs('multi_language')): ?>
                            <?php
                                $languages = App\Models\Language::all();
                                $language = $languages->where('code', '!=', session('lang'));
                                $activeLanguage = $languages->where('code', session('lang'))->first();
                            ?>
                            <li>
                                <div class="dropdown-lang dropdown mt-0">
                                    <a href="#" class="language-btn dropdown-toggle" data-bs-toggle="dropdown"
                                       aria-expanded="false">
                                        <img class="flag" src="<?php echo e(getImage(getFilePath('language') . '/' . @$activeLanguage->image, getFileSize('language'))); ?>" alt="us">
                                        <span class="language-text text-white"><?php echo e(__(@$activeLanguage->code)); ?></span>
                                    </a>
                                    <ul class="dropdown-menu" style="">
                                        <?php $__currentLoopData = $language; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <a href="javascript:void(0)" class="langSel" data-code="<?php echo e($item->code); ?>">
                                                    <img class="flag" src="<?php echo e(getImage(getFilePath('language') . '/' . @$item->image, getFileSize('language'))); ?>" alt="image">
                                                    <?php echo e(__(@$item->name)); ?>

                                                </a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </li>
                        <?php endif; ?>
                        <li class="d-none d-lg-block"><a class="btn btn--signup" href="<?php echo e(route('home')); ?>"> <?php echo app('translator')->get('Bet Now'); ?> </a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
</header>
<?php /**PATH /home3/dannygue/apuestas.ballosbet.com/core/resources/views/templates/basic/partials/user_header.blade.php ENDPATH**/ ?>