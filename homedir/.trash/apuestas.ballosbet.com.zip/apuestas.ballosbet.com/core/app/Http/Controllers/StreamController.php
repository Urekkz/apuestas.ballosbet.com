<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class StreamController extends Controller
{
    public function index()
    {
        // 🔒 Validar autenticación
        if (!auth()->check()) {
            return redirect()->route('user.login')
                ->with('error', 'Debes iniciar sesión para ver el stream.');
        }

        // 🔒 Validar que el usuario esté activo (status = 1)
        if (auth()->user()->status != 1) {
            auth()->logout();
            return redirect()->route('user.login')
                ->with('error', 'Tu cuenta está inactiva. Contacta con soporte.');
        }

        // ✅ Mostrar stream
        $path = storage_path('app/stream_url.txt');
        $url = file_exists($path) ? trim(file_get_contents($path)) : '';

        return view('stream', compact('url'));
    }

    public function update(Request $request)
    {
        // 🔒 Validar autenticación
        if (!auth()->check()) {
            return redirect()->route('user.login')
                ->with('error', 'Debes iniciar sesión para actualizar el stream.');
        }

        // 🔒 Validar que el usuario esté activo
        if (auth()->user()->status != 1) {
            auth()->logout();
            return redirect()->route('user.login')
                ->with('error', 'Tu cuenta está inactiva. Contacta con soporte.');
        }

        // ✅ Validar y guardar URL
        $request->validate([
            'stream_url' => 'required|url'
        ]);

        $path = storage_path('app/stream_url.txt');
        file_put_contents($path, $request->stream_url);

        return redirect()->route('stream')->with('success', 'Stream actualizado correctamente');
    }
}
