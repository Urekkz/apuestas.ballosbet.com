<?php

namespace App\Http\Controllers\User;

use App\Constants\Status;
use App\Http\Controllers\Controller;
use App\Lib\Referral;
use App\Models\Bet;
use App\Models\BetItem;
use App\Models\Transaction;
use Illuminate\Http\Request;

class BetController extends Controller {

    public function placeBet(Request $request) {
        $status = implode(',', [Status::SINGLE_BET, Status::MULTI_BET]);

        $request->validate([
            'type'         => "required|integer|in:$status",
            'stake_amount' => 'required_if:type,2|nullable|numeric|gt:0',
        ]);

        $user    = auth()->user();
        $betType = $request->type;
        $bets    = collect(session('bets'));

        $isSuspended = $bets->contains(function ($bet) {
            return isSuspendBet($bet);
        });

        if ($isSuspended) {
            $notify[] = ['error', 'You have to remove suspended bet from bet slip'];
            return back()->withNotify($notify);
        }

        if (blank($bets)) {
            $notify[] = ['error', 'No bet item found in bet slip'];
            return back()->withNotify($notify);
        }

        if ($bets->count() < 2 && $betType == Status::MULTI_BET) {
            $notify[] = ['error', 'Multi bet requires more than one bet'];
            return back()->withNotify($notify);
        }

        $totalStakeAmount = $betType == Status::SINGLE_BET ? getAmount($bets->sum('stake_amount'), 8) : $request->stake_amount;

        $minLimit = $betType == Status::SINGLE_BET ? gs('single_bet_min_limit') : gs('multi_bet_min_limit');
        $maxLimit = $betType == Status::SINGLE_BET ? gs('single_bet_max_limit') : gs('multi_bet_max_limit');

        if ($totalStakeAmount < $minLimit) {
            $notify[] = ['error', 'Min stake limit ' . $minLimit . ' ' . gs('cur_text')];
            return back()->withNotify($notify);
        }
        if ($totalStakeAmount > $maxLimit) {
            $notify[] = ['error', 'Max stake limit ' . $maxLimit . ' ' . gs('cur_text')];
            return back()->withNotify($notify);
        }

        if ($totalStakeAmount > $user->balance) {
            $notify[] = ['error', "You don't have sufficient balance"];
            return back()->withNotify($notify);
        }

        $user->balance -= $totalStakeAmount;
        $user->save();

        $transaction               = new Transaction();
        $transaction->user_id      = $user->id;
        $transaction->amount       = $totalStakeAmount;
        $transaction->post_balance = $user->balance;
        $transaction->trx_type     = '-';
        $transaction->details      = 'For bet placing';
        $transaction->trx          = getTrx();
        $transaction->remark       = 'bet_placed';
        $transaction->save();

        if ($betType == Status::SINGLE_BET) {
            $this->placeSingleBet();
        } else {
            $this->placeMultiBet();
        }

        if (gs('bet_commission') && gs('referral_program')) {
            Referral::levelCommission($user, $totalStakeAmount, $transaction->trx, 'bet');
        }

        session()->forget('bets');
        $notify[] = ['success', 'Bet placed successfully'];

        // If this was an AJAX request, return JSON with updated `my_bets` partial HTML
        if ($request->ajax()) {
            try {
                $html = view('templates.basic.partials.my_bets')->render();
            } catch (\Throwable $e) {
                $html = null;
            }

            return response()->json([
                'status' => 'success',
                'message' => 'Bet placed successfully',
                'html' => $html,
            ]);
        }

        return to_route('home', 'mybets')->withNotify($notify);
    }

    private function placeSingleBet() {
        $betData = collect(session('bets'));
        // Determinar si la apuesta debe marcarse como "abierta".
        // Antes estaba forzado a false (temporalmente deshabilitado). Ahora respetamos
        // el parámetro enviado desde el cliente si existe y es igual a 1.
        $isOpen = false;
        try {
            if (request()->has('is_open')) {
                // aceptar '1' o true como verdadero
                $isOpen = (string) request()->get('is_open') === '1' || request()->get('is_open') === 1 || request()->get('is_open') === true;
            }
        } catch (\Exception $e) {
            // Si por alguna razón request() no está disponible o hay un error,
            // conservamos el comportamiento por defecto (false).
            $isOpen = false;
        }

        foreach ($betData as $betItem) {
            $returnAmount = $betItem->stake_amount * $betItem->odds;
            $bet          = $this->saveBetData(Status::SINGLE_BET, $betItem->stake_amount, $returnAmount, $isOpen);
            $this->saveBetDetail($bet->id, $betItem);
        }
    }

    private function placeMultiBet() {

        $bet          = $this->saveBetData(Status::MULTI_BET, request()->stake_amount);
        $returnAmount = $bet->stake_amount;
        $betData      = collect(session('bets'));
        foreach ($betData as $betItem) {
            $returnAmount *= $betItem->odds;
            $this->saveBetDetail($bet->id, $betItem);
        }

        $bet->return_amount = $returnAmount;
        $bet->save();
    }

    private function saveBetData($type, $stakeAmount, $returnAmount = 0, $isOpen = false) {
        $bet                = new Bet();
        $bet->bet_number    = getTrx(8);
        $bet->user_id       = auth()->id();
        $bet->type          = $type;
        $bet->stake_amount  = $stakeAmount;
        $bet->return_amount = $returnAmount;
        $bet->status        = Status::BET_PENDING;
        $bet->is_open       = $isOpen; // Nueva funcionalidad: apuestas abiertas
        $bet->save();

        return $bet;
    }

    private function saveBetDetail($betId, $betItem) {
        $betDetail             = new BetItem();
        $betDetail->bet_id     = $betId;
        $betDetail->market_id  = $betItem->market_id;
        $betDetail->outcome_id = $betItem->outcome_id;
        $betDetail->odds       = $betItem->odds;
        $betDetail->status     = Status::BET_PENDING;
        $betDetail->save();
    }

    /**
     * Hacer que una apuesta sea "abierta" para que otros la puedan tapar
     */
    public function makeOpenBet(Request $request) {
        $request->validate([
            'bet_id' => 'required|exists:bets,id',
        ]);

        $user = auth()->user();
        $bet = Bet::where('id', $request->bet_id)
            ->where('user_id', $user->id)
            ->where('status', Status::BET_PENDING)
            ->whereNull('matched_bet_id')
            ->first();

        if (!$bet) {
            $notify[] = ['error', 'Bet not found or cannot be made open'];
            return back()->withNotify($notify);
        }

        $bet->is_open = true;
        $bet->save();

        $notify[] = ['success', 'Your bet is now open for matching'];
        
        if ($request->ajax()) {
            return response()->json([
                'status' => 'success',
                'message' => 'Your bet is now open for matching',
            ]);
        }

        return back()->withNotify($notify);
    }

    /**
     * Tapar una apuesta de otro usuario
     */
    public function matchBet(Request $request) {
        $request->validate([
            'original_bet_id' => 'required|exists:bets,id',
            'outcome_id' => 'required|exists:outcomes,id',
        ]);

        $user = auth()->user();
        
        // Obtener la apuesta original que se va a tapar
        $originalBet = Bet::where('id', $request->original_bet_id)
            ->where('is_open', true)
            ->where('status', Status::BET_PENDING)
            ->whereNull('matched_bet_id')
            ->with('bets')
            ->first();

        if (!$originalBet) {
            $notify[] = ['error', 'Bet is not available for matching'];
            
            if ($request->ajax()) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'Bet is not available for matching',
                ], 400);
            }
            return back()->withNotify($notify);
        }

        // No puedes tapar tu propia apuesta
        if ($originalBet->user_id == $user->id) {
            $notify[] = ['error', 'You cannot match your own bet'];
            
            if ($request->ajax()) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'You cannot match your own bet',
                ], 400);
            }
            return back()->withNotify($notify);
        }

        // Validar que el usuario tenga suficiente saldo
        $stakeAmount = $originalBet->stake_amount;
        
        if ($stakeAmount > $user->balance) {
            $notify[] = ['error', "You don't have sufficient balance to match this bet"];
            
            if ($request->ajax()) {
                return response()->json([
                    'status' => 'error',
                    'message' => "You don't have sufficient balance. Balance: " . showAmount($user->balance),
                ], 400);
            }
            return back()->withNotify($notify);
        }

        // Obtener el outcome y las odds
        $outcome = \App\Models\Outcome::find($request->outcome_id);
        if (!$outcome) {
            $notify[] = ['error', 'Invalid outcome'];
            
            if ($request->ajax()) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'Invalid outcome',
                ], 400);
            }
            return back()->withNotify($notify);
        }

        $returnAmount = $stakeAmount * $outcome->odds;

        // Descontar el saldo del usuario
        $user->balance -= $stakeAmount;
        $user->save();

        // Crear transacción
        $transaction               = new Transaction();
        $transaction->user_id      = $user->id;
        $transaction->amount       = $stakeAmount;
        $transaction->post_balance = $user->balance;
        $transaction->trx_type     = '-';
        $transaction->details      = 'For matching bet #' . $originalBet->bet_number;
        $transaction->trx          = getTrx();
        $transaction->remark       = 'bet_matched';
        $transaction->save();

        // Crear la nueva apuesta que tapa la original
        $matchingBet                = new Bet();
        $matchingBet->bet_number    = getTrx(8);
        $matchingBet->user_id       = $user->id;
        $matchingBet->type          = Status::SINGLE_BET;
        $matchingBet->stake_amount  = $stakeAmount;
        $matchingBet->return_amount = $returnAmount;
        $matchingBet->status        = Status::BET_PENDING;
        $matchingBet->is_open       = false;
        $matchingBet->matched_bet_id = $originalBet->id;
        $matchingBet->save();

        // Crear el detalle de la apuesta
        $originalBetItem = $originalBet->bets->first();
        
        $betDetail             = new BetItem();
        $betDetail->bet_id     = $matchingBet->id;
        $betDetail->market_id  = $originalBetItem->market_id;
        $betDetail->outcome_id = $outcome->id;
        $betDetail->odds       = $outcome->odds;
        $betDetail->status     = Status::BET_PENDING;
        $betDetail->save();

        // Actualizar la apuesta original para marcarla como tapada
        $originalBet->matched_bet_id = $matchingBet->id;
        $originalBet->matched_by_user_id = $user->id;
        $originalBet->matched_at = now();
        $originalBet->is_open = false; // Ya no está disponible
        $originalBet->save();

        // Comisión de referidos si aplica
        if (gs('bet_commission') && gs('referral_program')) {
            Referral::levelCommission($user, $stakeAmount, $transaction->trx, 'bet');
        }

        $notify[] = ['success', 'Bet matched successfully!'];

        if ($request->ajax()) {
            try {
                $html = view('templates.basic.partials.my_bets')->render();
            } catch (\Throwable $e) {
                $html = null;
            }

            return response()->json([
                'status' => 'success',
                'message' => 'Bet matched successfully!',
                'html' => $html,
            ]);
        }

        return to_route('home', 'mybets')->withNotify($notify);
    }
}




