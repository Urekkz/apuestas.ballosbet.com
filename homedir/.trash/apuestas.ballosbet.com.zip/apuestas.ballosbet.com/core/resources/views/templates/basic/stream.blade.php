@extends('templates.basic.layout') {{-- Asegúrate de que este sea tu layout principal --}}

@section('content')
<div class="container text-center my-5">
    <h1 style="color:white;">🎥 Transmisión en Vivo</h1>

    {{-- Formulario para que el admin actualice la URL del live --}}
    @if(auth()->check() && auth()->user()->is_admin)
        <form action="{{ route('stream.update') }}" method="POST" class="mb-4" style="max-width:600px; margin:auto;">
            @csrf
            <input type="url" name="stream_url" value="{{ $url }}" class="form-control mb-2" placeholder="Pega aquí la URL del live de Facebook" required>
            <button type="submit" class="btn btn-primary w-100">Actualizar Stream</button>
        </form>
    @endif

    {{-- Mostrar el stream si existe --}}
    @if($url)
        <div class="ratio ratio-16x9 mt-4" style="max-width: 900px; margin:auto;">
            <iframe
                src="https://www.facebook.com/plugins/video.php?href={{ urlencode($url) }}&show_text=false&autoplay=true"
                width="900"
                height="506"
                style="border:none;overflow:hidden;border-radius:10px;"
                scrolling="no"
                frameborder="0"
                allowfullscreen="true"
                allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share">
            </iframe>
        </div>
    @else
        <p class="mt-4" style="color:white;">No hay stream activo en este momento.</p>
    @endif
</div>
@endsection
