@props(['marketType', 'game', 'betPlacedIds' => []])

@php
    $market = $game->markets->firstWhere('market_type', $marketType);
    $outcomeOne = $market?->outcomes->first();
    $outcomeTwo = $market?->outcomes->skip(1)->first();
    
    // Usar los nombres reales de los outcomes
    $nameOne = $outcomeOne?->name ?? 'Gallo 1';
    $nameTwo = $outcomeTwo?->name ?? 'Gallo 2';
@endphp

<div class="sports-card-inner text-center">
    {{-- Encabezado con nombres de gallos --}}
    <div class="sports-card-top-inner sports-card-heading d-flex justify-content-center align-items-center mb-3 flex-wrap">
        <span class="team-select-title mx-2 fw-bold">{{ __($nameOne) }}</span>
        <span class="team-select-title mx-2 text-warning fw-bold">VS</span>
        <span class="team-select-title mx-2 fw-bold">{{ __($nameTwo) }}</span>
    </div>

    {{-- Cuerpo centrado --}}
    <div class="sports-card-body d-flex flex-column align-items-center justify-content-center">
        {{-- Botones de apuestas (Gallo 1 y Gallo 2) --}}
        <div class="option-odd-lists d-flex justify-content-center align-items-center gap-3 mb-4 flex-wrap">
            <x-frontend.odds-button 
                :outcome="$outcomeOne" 
                :marketIsLocked="@$market->locked"
                :betPlacedIds="$betPlacedIds"
            />
            <x-frontend.odds-button 
                :outcome="$outcomeTwo" 
                :marketIsLocked="@$market->locked"
                :betPlacedIds="$betPlacedIds"
            />
        </div>

        {{-- Botones de montos debajo --}}
        <div class="bet-amount-buttons text-center w-100">
            <div class="d-flex justify-content-center gap-3 flex-wrap mb-3">
                <button class="btn btn-outline-success bet-amount-btn fw-semibold" data-amount="20">$20</button>
                <button class="btn btn-outline-success bet-amount-btn fw-semibold" data-amount="30">$30</button>
                <button class="btn btn-outline-warning custom-bet fw-semibold">Apuesta personalizada</button>
            </div>
            
            {{-- Todas las apuestas son abiertas automáticamente --}}
            @auth
            <div class="text-center mt-2">
                <small class="text-muted">
                    <i class="las la-info-circle"></i> Todas las apuestas son públicas y pueden ser tapadas por otros usuarios
                </small>
            </div>
            @endauth
        </div>
    </div>
</div>

{{-- Modal para monto personalizado --}}
<div class="custom-modal" style="display:none;">
    <div class="custom-modal-content text-center">
        <h6 class="mb-3">Monto personalizado</h6>
        <input type="number" class="form-control text-center mb-3" id="customBetInput" placeholder="Ej: 50">
        <div class="d-flex justify-content-center gap-2">
            <button class="btn btn-primary btn-sm save-custom-bet">Aceptar</button>
            <button class="btn btn-secondary btn-sm cancel-custom-bet">Cancelar</button>
        </div>
    </div>
</div>

<style>
/* Centrado del contenedor */
.sports-card-inner {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
}

.option-odd-lists {
    flex-wrap: wrap;
}

/* Variables base */
:root {
    --base: 24 89% 55%;
    --white: 0 0% 100%;
}

/* Botones de monto de apuesta */
.bet-amount-buttons .bet-amount-btn {
    min-width: 92px;
    padding: 10px 14px;
    border-radius: 10px;
    background: hsl(var(--base));
    color: hsl(var(--white));
    border: 1px solid hsl(var(--base));
    font-weight: 700;
    box-shadow: 0 3px 10px rgba(0, 0, 0, 0.18);
    transition: transform 0.12s ease, box-shadow 0.12s ease, background 0.12s ease, color 0.12s ease;
    cursor: pointer;
}

.bet-amount-buttons .bet-amount-btn:hover,
.bet-amount-buttons .bet-amount-btn:focus {
    background: linear-gradient(180deg, rgba(255,159,67,1) 0%, rgba(255,122,0,1) 100%);
    color: hsl(var(--white));
    border-color: hsl(var(--base));
    transform: translateY(-3px);
    box-shadow: 0 12px 30px rgba(255,159,67,0.18);
    outline: none;
}

.bet-amount-buttons .bet-amount-btn:active {
    transform: translateY(-1px);
    box-shadow: 0 6px 14px rgba(0, 0, 0, 0.12);
}

/* Bot�n personalizado */
.bet-amount-buttons .custom-bet {
    padding: 10px 16px;
    border-radius: 10px;
    border: none;
    background: hsl(var(--base));
    color: hsl(var(--white));
    font-weight: 800;
    box-shadow: 0 10px 28px rgba(255,159,67,0.18);
    transition: transform 0.12s ease, box-shadow 0.12s ease, opacity 0.12s ease;
}

.bet-amount-buttons .custom-bet:hover,
.bet-amount-buttons .custom-bet:focus {
    transform: translateY(-3px);
    box-shadow: 0 16px 36px rgba(255,122,0,0.22);
    opacity: 0.98;
}

/* Botones de acci�n del modal */
.save-custom-bet {
    background: #ff7a00 !important;
    border-color: #ff7a00 !important;
    color: #111 !important;
}

.cancel-custom-bet {
    background: #2b2b2b !important;
    color: #fff !important;
    border: none !important;
}

/* Modal */
.custom-modal {
    position: fixed;
    top: 0; left: 0;
    width: 100%; height: 100%;
    background: rgba(0, 0, 0, 0.6);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 9999;
}

.custom-modal-content {
    background: #ffffff;
    padding: 22px 20px;
    border-radius: 12px;
    width: 320px;
    max-width: calc(100% - 40px);
    box-shadow: 0 12px 40px rgba(0, 0, 0, 0.35);
}

/* Responsividad */
@media (max-width: 576px) {
    .bet-amount-buttons .bet-amount-btn {
        min-width: 76px;
        padding: 8px 10px;
        border-radius: 8px;
        font-size: 0.9rem;
    }

    .bet-amount-buttons .custom-bet {
        padding: 8px 10px;
        font-size: 0.95rem;
    }
}
</style>





